#pragma line 1 "D:/UET/3-2/HLS/Last/MatConv.cpp"
#pragma line 1 "<built-in>"
#pragma line 1 "<command-line>"
#pragma line 1 "D:/UET/3-2/HLS/Last/MatConv.cpp"
#pragma line 1 "D:/UET/3-2/HLS/Last/MatConv.h" 1
#pragma line 15 "D:/UET/3-2/HLS/Last/MatConv.h"
typedef unsigned char mat_ker;
typedef unsigned char mat_inp;
typedef unsigned char mat_outp;
#pragma empty_line
#pragma empty_line
#pragma empty_line
void MatConv(
    mat_ker ker[5][5],
    mat_inp inp[15][15],
    mat_outp outp[(15 - 5 + 1)][(15 - 5 + 1)]
);
#pragma line 2 "D:/UET/3-2/HLS/Last/MatConv.cpp" 2
#pragma empty_line
void MatConv(
 mat_ker ker[5][5],
 mat_inp inp[15][15],
 mat_outp outp[(15 - 5 + 1)][(15 - 5 + 1)]
){
    Output_Rows: for(int i = 0; i < (15 - 5 + 1); i++){
        Output_Cols: for(int j = 0; j < (15 - 5 + 1); j++){
            outp[i][j] = 0;
            Ker_Rows: for (int y = 0; y < 5; y++){
                Ker_Cols: for (int x = 0; x < 5; x++){
                    outp[i][j] += ker[y][x] * inp[i + y][j + x];
                }
            }
        }
    }
}
