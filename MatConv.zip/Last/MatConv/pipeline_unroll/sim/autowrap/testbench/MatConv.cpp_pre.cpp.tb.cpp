// ==============================================================
// File generated on Sat May 24 15:42:07 +0700 2025
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#1 "D:/UET/3-2/HLS/Last/MatConv.cpp"
#1 "<built-in>"
#1 "<command-line>"
#1 "D:/UET/3-2/HLS/Last/MatConv.cpp"
#1 "D:/UET/3-2/HLS/Last/MatConv.h" 1
#15 "D:/UET/3-2/HLS/Last/MatConv.h"
typedef unsigned char mat_ker;
typedef unsigned char mat_inp;
typedef unsigned char mat_outp;



void MatConv(
    mat_ker ker[5][5],
    mat_inp inp[15][15],
    mat_outp outp[(15 - 5 + 1)][(15 - 5 + 1)]
);
#2 "D:/UET/3-2/HLS/Last/MatConv.cpp" 2

void MatConv(
 mat_ker ker[5][5],
 mat_inp inp[15][15],
 mat_outp outp[(15 - 5 + 1)][(15 - 5 + 1)]
){
    Output_Rows: for(int i = 0; i < (15 - 5 + 1); i++){
        Output_Cols: for(int j = 0; j < (15 - 5 + 1); j++){
            outp[i][j] = 0;
            Ker_Rows: for (int y = 0; y < 5; y++){
                Ker_Cols: for (int x = 0; x < 5; x++){
                    outp[i][j] += ker[y][x] * inp[i + y][j + x];
                }
            }
        }
    }
}
