// ==============================================================
// File generated on Sat May 24 15:42:12 +0700 2025
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_MatConv (
char ker[5][5],
char inp[15][15],
short outp[11][11]);
