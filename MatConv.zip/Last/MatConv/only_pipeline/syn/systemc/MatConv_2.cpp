#include "MatConv.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void MatConv::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_state1;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter0 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_logic_1, ap_condition_pp0_exit_iter0_state2.read()))) {
            ap_enable_reg_pp0_iter0 = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                    esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
            ap_enable_reg_pp0_iter0 = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter1 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0)) {
            if (esl_seteq<1,1,1>(ap_const_logic_1, ap_condition_pp0_exit_iter0_state2.read())) {
                ap_enable_reg_pp0_iter1 = (ap_condition_pp0_exit_iter0_state2.read() ^ ap_const_logic_1);
            } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
                ap_enable_reg_pp0_iter1 = ap_enable_reg_pp0_iter0.read();
            }
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter2 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp0_iter2 = ap_enable_reg_pp0_iter1.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter3 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp0_iter3 = ap_enable_reg_pp0_iter2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                    esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
            ap_enable_reg_pp0_iter3 = ap_const_logic_0;
        }
    }
    if (esl_seteq<1,1,1>(ap_condition_1045.read(), ap_const_boolean_1)) {
        if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
             esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_1))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_1_0.read();
        } else if (esl_seteq<1,1,1>(ap_condition_1111.read(), ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_10_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_9))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_9_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_8))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_8_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_7))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_7_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_6))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_6_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_5))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_5_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_4))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_4_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_3))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_3_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_2))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_2_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_0))) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = inp_0_0.read();
        } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157 = ap_phi_reg_pp0_iter0_inp_load_0_0_0_phi_reg_3157.read();
        }
    }
    if (esl_seteq<1,1,1>(ap_condition_1045.read(), ap_const_boolean_1)) {
        if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
             esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_0))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_4_0.read();
        } else if (esl_seteq<1,1,1>(ap_condition_1111.read(), ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_14_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_9))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_13_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_8))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_12_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_7))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_11_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_6))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_10_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_5))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_9_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_4))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_8_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_3))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_7_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_2))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_6_0.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_1))) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = inp_5_0.read();
        } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_inp_load_0_4_0_phi_reg_3185 = ap_phi_reg_pp0_iter0_inp_load_0_4_0_phi_reg_3185.read();
        }
    }
    if (esl_seteq<1,1,1>(ap_condition_1045.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_1111.read(), ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_10_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_9))) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_9_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_8))) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_8_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_7))) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_7_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_6))) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_6_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_5))) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_5_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_4))) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_4_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_3))) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_3_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_2))) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_2_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_0))) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = inp_0_14.read();
        } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239 = ap_phi_reg_pp0_iter0_inp_load_10_0_4_phi_reg_3239.read();
        }
    }
    if (esl_seteq<1,1,1>(ap_condition_1045.read(), ap_const_boolean_1)) {
        if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
             esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_0))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_4_14.read();
        } else if (esl_seteq<1,1,1>(ap_condition_1111.read(), ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_14_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_9))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_13_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_8))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_12_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_7))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_11_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_6))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_10_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_5))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_9_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_4))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_8_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_3))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_7_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_2))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_6_14.read();
        } else if ((esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,4,4>(ap_phi_mux_i_phi_fu_3149_p4.read(), ap_const_lv4_1))) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = inp_5_14.read();
        } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_inp_load_10_4_4_phi_reg_3212 = ap_phi_reg_pp0_iter0_inp_load_10_4_4_phi_reg_3212.read();
        }
    }
    if (esl_seteq<1,1,1>(ap_condition_1346.read(), ap_const_boolean_1)) {
        if ((esl_seteq<1,1,1>(exitcond3_reg_18147.read(), ap_const_lv1_0) && 
             esl_seteq<1,4,4>(i_reg_3145.read(), ap_const_lv4_1))) {
            ap_phi_reg_pp0_iter2_inp_load_10_0_4_phi_reg_3239 = inp_1_14.read();
        } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter2_inp_load_10_0_4_phi_reg_3239 = ap_phi_reg_pp0_iter1_inp_load_10_0_4_phi_reg_3239.read();
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(exitcond3_reg_18147.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        i_reg_3145 = i_1_reg_18151.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        i_reg_3145 = ap_const_lv4_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        exitcond3_reg_18147 = exitcond3_fu_3366_p2.read();
        i_reg_3145_pp0_iter1_reg = i_reg_3145.read();
        inp_load_0_4_2_phi_reg_18885 = inp_load_0_4_2_phi_fu_6217_p18.read();
        inp_load_1_0_0_phi_reg_18920 = inp_load_1_0_0_phi_fu_6295_p18.read();
        inp_load_1_0_3_phi_reg_18925 = inp_load_1_0_3_phi_fu_6351_p18.read();
        inp_load_1_2_2_phi_reg_18930 = inp_load_1_2_2_phi_fu_6476_p18.read();
        inp_load_1_3_0_phi_reg_18935 = inp_load_1_3_0_phi_fu_6530_p18.read();
        inp_load_1_3_3_phi_reg_18940 = inp_load_1_3_3_phi_fu_6584_p18.read();
        inp_load_1_4_2_phi_reg_18945 = inp_load_1_4_2_phi_fu_6663_p18.read();
        inp_load_2_0_0_phi_reg_18995 = inp_load_2_0_0_phi_fu_6717_p18.read();
        inp_load_2_0_3_phi_reg_19000 = inp_load_2_0_3_phi_fu_6773_p18.read();
        inp_load_2_2_2_phi_reg_19005 = inp_load_2_2_2_phi_fu_6898_p18.read();
        inp_load_2_3_0_phi_reg_19010 = inp_load_2_3_0_phi_fu_6952_p18.read();
        inp_load_2_3_3_phi_reg_19015 = inp_load_2_3_3_phi_fu_7006_p18.read();
        inp_load_2_4_2_phi_reg_19020 = inp_load_2_4_2_phi_fu_7085_p18.read();
        inp_load_3_0_0_phi_reg_19070 = inp_load_3_0_0_phi_fu_7139_p18.read();
        inp_load_3_0_3_phi_reg_19075 = inp_load_3_0_3_phi_fu_7195_p18.read();
        inp_load_3_2_2_phi_reg_19080 = inp_load_3_2_2_phi_fu_7320_p18.read();
        inp_load_3_3_0_phi_reg_19085 = inp_load_3_3_0_phi_fu_7374_p18.read();
        inp_load_3_3_3_phi_reg_19090 = inp_load_3_3_3_phi_fu_7428_p18.read();
        inp_load_3_4_2_phi_reg_19095 = inp_load_3_4_2_phi_fu_7507_p18.read();
        inp_load_4_0_0_phi_reg_19145 = inp_load_4_0_0_phi_fu_7561_p18.read();
        inp_load_4_0_3_phi_reg_19150 = inp_load_4_0_3_phi_fu_7617_p18.read();
        inp_load_4_2_2_phi_reg_19155 = inp_load_4_2_2_phi_fu_7742_p18.read();
        inp_load_4_3_0_phi_reg_19160 = inp_load_4_3_0_phi_fu_7796_p18.read();
        inp_load_4_3_3_phi_reg_19165 = inp_load_4_3_3_phi_fu_7850_p18.read();
        inp_load_4_4_2_phi_reg_19170 = inp_load_4_4_2_phi_fu_7929_p18.read();
        inp_load_5_0_0_phi_reg_19220 = inp_load_5_0_0_phi_fu_7983_p18.read();
        inp_load_5_0_3_phi_reg_19225 = inp_load_5_0_3_phi_fu_8039_p18.read();
        inp_load_5_2_2_phi_reg_19230 = inp_load_5_2_2_phi_fu_8164_p18.read();
        inp_load_5_3_0_phi_reg_19235 = inp_load_5_3_0_phi_fu_8218_p18.read();
        inp_load_5_3_3_phi_reg_19240 = inp_load_5_3_3_phi_fu_8272_p18.read();
        inp_load_5_4_2_phi_reg_19245 = inp_load_5_4_2_phi_fu_8351_p18.read();
        inp_load_6_0_0_phi_reg_19295 = inp_load_6_0_0_phi_fu_8405_p18.read();
        inp_load_6_0_3_phi_reg_19300 = inp_load_6_0_3_phi_fu_8461_p18.read();
        inp_load_6_2_2_phi_reg_19305 = inp_load_6_2_2_phi_fu_8586_p18.read();
        inp_load_6_3_0_phi_reg_19310 = inp_load_6_3_0_phi_fu_8640_p18.read();
        inp_load_6_3_3_phi_reg_19315 = inp_load_6_3_3_phi_fu_8694_p18.read();
        inp_load_6_4_2_phi_reg_19320 = inp_load_6_4_2_phi_fu_8773_p18.read();
        inp_load_7_0_0_phi_reg_19370 = inp_load_7_0_0_phi_fu_8827_p18.read();
        inp_load_7_0_3_phi_reg_19375 = inp_load_7_0_3_phi_fu_8883_p18.read();
        inp_load_7_2_2_phi_reg_19380 = inp_load_7_2_2_phi_fu_9008_p18.read();
        inp_load_7_3_0_phi_reg_19385 = inp_load_7_3_0_phi_fu_9062_p18.read();
        inp_load_7_3_3_phi_reg_19390 = inp_load_7_3_3_phi_fu_9116_p18.read();
        inp_load_7_4_2_phi_reg_19395 = inp_load_7_4_2_phi_fu_9195_p18.read();
        inp_load_8_0_0_phi_reg_19445 = inp_load_8_0_0_phi_fu_9249_p18.read();
        inp_load_8_0_3_phi_reg_19450 = inp_load_8_0_3_phi_fu_9305_p18.read();
        inp_load_8_2_2_phi_reg_19455 = inp_load_8_2_2_phi_fu_9430_p18.read();
        inp_load_8_3_0_phi_reg_19460 = inp_load_8_3_0_phi_fu_9484_p18.read();
        inp_load_8_3_3_phi_reg_19465 = inp_load_8_3_3_phi_fu_9538_p18.read();
        inp_load_8_4_2_phi_reg_19470 = inp_load_8_4_2_phi_fu_9617_p18.read();
        inp_load_9_0_0_phi_reg_19520 = inp_load_9_0_0_phi_fu_9671_p18.read();
        inp_load_9_0_3_phi_reg_19525 = inp_load_9_0_3_phi_fu_9727_p18.read();
        inp_load_9_2_2_phi_reg_19530 = inp_load_9_2_2_phi_fu_9852_p18.read();
        inp_load_9_3_0_phi_reg_19535 = inp_load_9_3_0_phi_fu_9906_p18.read();
        inp_load_9_3_3_phi_reg_19540 = inp_load_9_3_3_phi_fu_9960_p18.read();
        inp_load_9_4_2_phi_reg_19545 = inp_load_9_4_2_phi_fu_10039_p18.read();
        tmp17_reg_18910 = tmp17_fu_6289_p2.read();
        tmp231_reg_19635 = tmp231_fu_10513_p2.read();
        tmp234_reg_19640 = tmp234_fu_10525_p2.read();
        tmp236_reg_19645 = tmp236_fu_10531_p2.read();
        tmp239_reg_19650 = tmp239_fu_10543_p2.read();
        tmp247_reg_19655 = tmp247_fu_10549_p2.read();
        tmp251_reg_19660 = tmp251_fu_10561_p2.read();
        tmp6_reg_18900 = tmp6_fu_6271_p2.read();
        tmp9_reg_18905 = tmp9_fu_6283_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()))) {
        i_1_reg_18151 = i_1_fu_3372_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) {
        i_reg_3145_pp0_iter2_reg = i_reg_3145_pp0_iter1_reg.read();
        tmp102_reg_19740 = tmp102_fu_10863_p2.read();
        tmp10_reg_19670 = tmp10_fu_10657_p2.read();
        tmp115_reg_19745 = tmp115_fu_10880_p2.read();
        tmp120_reg_19750 = tmp120_fu_10904_p2.read();
        tmp125_reg_19755 = tmp125_fu_10908_p2.read();
        tmp138_reg_19760 = tmp138_fu_10925_p2.read();
        tmp13_reg_19675 = tmp13_fu_10668_p2.read();
        tmp143_reg_19765 = tmp143_fu_10949_p2.read();
        tmp148_reg_19770 = tmp148_fu_10953_p2.read();
        tmp15_reg_19680 = tmp15_fu_10680_p2.read();
        tmp161_reg_19775 = tmp161_fu_10970_p2.read();
        tmp166_reg_19780 = tmp166_fu_10994_p2.read();
        tmp171_reg_19785 = tmp171_fu_10998_p2.read();
        tmp184_reg_19790 = tmp184_fu_11015_p2.read();
        tmp189_reg_19795 = tmp189_fu_11039_p2.read();
        tmp194_reg_19800 = tmp194_fu_11043_p2.read();
        tmp207_reg_19805 = tmp207_fu_11060_p2.read();
        tmp212_reg_19810 = tmp212_fu_11084_p2.read();
        tmp217_reg_19815 = tmp217_fu_11088_p2.read();
        tmp22_reg_19685 = tmp22_fu_10700_p2.read();
        tmp230_reg_19820 = tmp230_fu_11105_p2.read();
        tmp235_reg_19825 = tmp235_fu_11189_p2.read();
        tmp240_reg_19830 = tmp240_fu_11199_p2.read();
        tmp243_reg_19835 = tmp243_fu_11210_p2.read();
        tmp245_reg_19840 = tmp245_fu_11222_p2.read();
        tmp252_reg_19845 = tmp252_fu_11233_p2.read();
        tmp28_reg_19690 = tmp28_fu_10724_p2.read();
        tmp33_reg_19695 = tmp33_fu_10728_p2.read();
        tmp46_reg_19700 = tmp46_fu_10745_p2.read();
        tmp51_reg_19705 = tmp51_fu_10769_p2.read();
        tmp56_reg_19710 = tmp56_fu_10773_p2.read();
        tmp5_reg_19665 = tmp5_fu_10647_p2.read();
        tmp69_reg_19715 = tmp69_fu_10790_p2.read();
        tmp74_reg_19720 = tmp74_fu_10814_p2.read();
        tmp79_reg_19725 = tmp79_fu_10818_p2.read();
        tmp92_reg_19730 = tmp92_fu_10835_p2.read();
        tmp97_reg_19735 = tmp97_fu_10859_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        inp_load_0_0_0_phi_reg_3157 = ap_phi_reg_pp0_iter1_inp_load_0_0_0_phi_reg_3157.read();
        tmp100_reg_19190 = grp_fu_11747_p3.read();
        tmp104_reg_19195 = grp_fu_11706_p3.read();
        tmp106_reg_19200 = grp_fu_11713_p3.read();
        tmp110_reg_19205 = grp_fu_11720_p3.read();
        tmp111_reg_19210 = grp_fu_11733_p3.read();
        tmp112_reg_19215 = grp_fu_11768_p3.read();
        tmp116_reg_19250 = grp_fu_11830_p3.read();
        tmp118_reg_19255 = grp_fu_11823_p3.read();
        tmp121_reg_19260 = grp_fu_11809_p3.read();
        tmp123_reg_19265 = grp_fu_11816_p3.read();
        tmp127_reg_19270 = grp_fu_11775_p3.read();
        tmp129_reg_19275 = grp_fu_11782_p3.read();
        tmp133_reg_19280 = grp_fu_11789_p3.read();
        tmp134_reg_19285 = grp_fu_11802_p3.read();
        tmp135_reg_19290 = grp_fu_11837_p3.read();
        tmp139_reg_19325 = grp_fu_11899_p3.read();
        tmp141_reg_19330 = grp_fu_11892_p3.read();
        tmp144_reg_19335 = grp_fu_11878_p3.read();
        tmp146_reg_19340 = grp_fu_11885_p3.read();
        tmp150_reg_19345 = grp_fu_11844_p3.read();
        tmp152_reg_19350 = grp_fu_11851_p3.read();
        tmp156_reg_19355 = grp_fu_11858_p3.read();
        tmp157_reg_19360 = grp_fu_11871_p3.read();
        tmp158_reg_19365 = grp_fu_11906_p3.read();
        tmp162_reg_19400 = grp_fu_11968_p3.read();
        tmp164_reg_19405 = grp_fu_11961_p3.read();
        tmp167_reg_19410 = grp_fu_11947_p3.read();
        tmp169_reg_19415 = grp_fu_11954_p3.read();
        tmp173_reg_19420 = grp_fu_11913_p3.read();
        tmp175_reg_19425 = grp_fu_11920_p3.read();
        tmp179_reg_19430 = grp_fu_11927_p3.read();
        tmp180_reg_19435 = grp_fu_11940_p3.read();
        tmp181_reg_19440 = grp_fu_11975_p3.read();
        tmp185_reg_19475 = grp_fu_12037_p3.read();
        tmp187_reg_19480 = grp_fu_12030_p3.read();
        tmp190_reg_19485 = grp_fu_12016_p3.read();
        tmp192_reg_19490 = grp_fu_12023_p3.read();
        tmp196_reg_19495 = grp_fu_11982_p3.read();
        tmp198_reg_19500 = grp_fu_11989_p3.read();
        tmp1_reg_18890 = grp_fu_11485_p3.read();
        tmp202_reg_19505 = grp_fu_11996_p3.read();
        tmp203_reg_19510 = grp_fu_12009_p3.read();
        tmp204_reg_19515 = grp_fu_12044_p3.read();
        tmp208_reg_19550 = grp_fu_12106_p3.read();
        tmp20_reg_18915 = grp_fu_11492_p3.read();
        tmp210_reg_19555 = grp_fu_12099_p3.read();
        tmp213_reg_19560 = grp_fu_12085_p3.read();
        tmp215_reg_19565 = grp_fu_12092_p3.read();
        tmp219_reg_19570 = grp_fu_12051_p3.read();
        tmp221_reg_19575 = grp_fu_12058_p3.read();
        tmp225_reg_19580 = grp_fu_12065_p3.read();
        tmp226_reg_19585 = grp_fu_12078_p3.read();
        tmp227_reg_19590 = grp_fu_12113_p3.read();
        tmp24_reg_18950 = grp_fu_11554_p3.read();
        tmp26_reg_18955 = grp_fu_11547_p3.read();
        tmp29_reg_18960 = grp_fu_11533_p3.read();
        tmp31_reg_18965 = grp_fu_11540_p3.read();
        tmp35_reg_18970 = grp_fu_11499_p3.read();
        tmp37_reg_18975 = grp_fu_11506_p3.read();
        tmp3_reg_18895 = grp_fu_11478_p3.read();
        tmp41_reg_18980 = grp_fu_11513_p3.read();
        tmp42_reg_18985 = grp_fu_11526_p3.read();
        tmp43_reg_18990 = grp_fu_11561_p3.read();
        tmp47_reg_19025 = grp_fu_11623_p3.read();
        tmp49_reg_19030 = grp_fu_11616_p3.read();
        tmp52_reg_19035 = grp_fu_11602_p3.read();
        tmp54_reg_19040 = grp_fu_11609_p3.read();
        tmp58_reg_19045 = grp_fu_11568_p3.read();
        tmp60_reg_19050 = grp_fu_11575_p3.read();
        tmp64_reg_19055 = grp_fu_11582_p3.read();
        tmp65_reg_19060 = grp_fu_11595_p3.read();
        tmp66_reg_19065 = grp_fu_11630_p3.read();
        tmp70_reg_19100 = grp_fu_11692_p3.read();
        tmp72_reg_19105 = grp_fu_11685_p3.read();
        tmp75_reg_19110 = grp_fu_11671_p3.read();
        tmp77_reg_19115 = grp_fu_11678_p3.read();
        tmp81_reg_19120 = grp_fu_11637_p3.read();
        tmp83_reg_19125 = grp_fu_11644_p3.read();
        tmp87_reg_19130 = grp_fu_11651_p3.read();
        tmp88_reg_19135 = grp_fu_11664_p3.read();
        tmp89_reg_19140 = grp_fu_11699_p3.read();
        tmp93_reg_19175 = grp_fu_11761_p3.read();
        tmp95_reg_19180 = grp_fu_11754_p3.read();
        tmp98_reg_19185 = grp_fu_11740_p3.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(exitcond3_reg_18147.read(), ap_const_lv1_0))) {
        inp_load_0_0_1_phi_reg_18835 = inp_load_0_0_1_phi_fu_5796_p18.read();
        inp_load_0_0_2_phi_reg_18840 = inp_load_0_0_2_phi_fu_5818_p18.read();
        inp_load_0_0_3_phi_reg_18845 = inp_load_0_0_3_phi_fu_5840_p18.read();
        inp_load_0_0_4_phi_reg_18850 = inp_load_0_0_4_phi_fu_5862_p18.read();
        inp_load_0_1_0_phi_reg_18855 = inp_load_0_1_0_phi_fu_5884_p18.read();
        inp_load_0_1_1_phi_reg_18860 = inp_load_0_1_1_phi_fu_5905_p18.read();
        inp_load_0_2_2_phi_reg_18875 = inp_load_0_2_2_phi_fu_6054_p18.read();
        inp_load_0_3_3_phi_reg_18880 = inp_load_0_3_3_phi_fu_6159_p18.read();
        inp_load_10_0_0_phi_reg_19595 = inp_load_10_0_0_phi_fu_10093_p18.read();
        inp_load_10_0_1_phi_reg_19600 = inp_load_10_0_1_phi_fu_10115_p18.read();
        inp_load_10_0_2_phi_reg_19605 = inp_load_10_0_2_phi_fu_10137_p18.read();
        inp_load_10_0_3_phi_reg_19610 = inp_load_10_0_3_phi_fu_10159_p18.read();
        inp_load_10_1_0_phi_reg_19615 = inp_load_10_1_0_phi_fu_10181_p18.read();
        inp_load_10_1_1_phi_reg_19620 = inp_load_10_1_1_phi_fu_10202_p18.read();
        inp_load_10_2_2_phi_reg_19625 = inp_load_10_2_2_phi_fu_10299_p18.read();
        inp_load_10_4_2_phi_reg_19630 = inp_load_10_4_2_phi_fu_10458_p18.read();
        tmp_7_0_1_4_reg_18865 = tmp_7_0_1_4_fu_6011_p2.read();
        tmp_7_0_2_1_reg_18870 = tmp_7_0_2_1_fu_6049_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_0))) {
        inp_load_0_2_0_phi_reg_18217 = inp_load_0_2_0_phi_fu_3384_p18.read();
        inp_load_0_3_0_phi_reg_18263 = inp_load_0_3_0_phi_fu_3412_p18.read();
        inp_load_0_3_1_phi_reg_18268 = inp_load_0_3_1_phi_fu_3434_p18.read();
        inp_load_0_3_2_phi_reg_18273 = inp_load_0_3_2_phi_fu_3456_p18.read();
        inp_load_0_3_4_phi_reg_18278 = inp_load_0_3_4_phi_fu_3478_p18.read();
        inp_load_0_4_3_phi_reg_18325 = inp_load_0_4_3_phi_fu_3506_p18.read();
        inp_load_10_1_4_phi_reg_18785 = inp_load_10_1_4_phi_fu_5589_p18.read();
        inp_load_10_2_1_phi_reg_18795 = inp_load_10_2_1_phi_fu_5642_p18.read();
        inp_load_10_3_0_phi_reg_18800 = inp_load_10_3_0_phi_fu_5664_p18.read();
        inp_load_10_3_1_phi_reg_18805 = inp_load_10_3_1_phi_fu_5686_p18.read();
        inp_load_10_3_2_phi_reg_18810 = inp_load_10_3_2_phi_fu_5708_p18.read();
        inp_load_10_3_3_phi_reg_18815 = inp_load_10_3_3_phi_fu_5730_p18.read();
        inp_load_10_3_4_phi_reg_18820 = inp_load_10_3_4_phi_fu_5752_p18.read();
        inp_load_10_4_0_phi_reg_18825 = inp_load_10_4_0_phi_fu_5774_p18.read();
        inp_load_1_0_2_phi_reg_18330 = inp_load_1_0_2_phi_fu_3528_p18.read();
        inp_load_1_1_0_phi_reg_18335 = inp_load_1_1_0_phi_fu_3550_p18.read();
        inp_load_1_1_2_phi_reg_18340 = inp_load_1_1_2_phi_fu_3572_p18.read();
        inp_load_1_1_4_phi_reg_18350 = inp_load_1_1_4_phi_fu_3625_p18.read();
        inp_load_1_2_0_phi_reg_18355 = inp_load_1_2_0_phi_fu_3647_p18.read();
        inp_load_1_2_4_phi_reg_18360 = inp_load_1_2_4_phi_fu_3669_p18.read();
        inp_load_1_3_2_phi_reg_18365 = inp_load_1_3_2_phi_fu_3691_p18.read();
        inp_load_1_4_0_phi_reg_18370 = inp_load_1_4_0_phi_fu_3713_p18.read();
        inp_load_1_4_3_phi_reg_18375 = inp_load_1_4_3_phi_fu_3735_p18.read();
        inp_load_2_0_2_phi_reg_18380 = inp_load_2_0_2_phi_fu_3757_p18.read();
        inp_load_2_1_0_phi_reg_18385 = inp_load_2_1_0_phi_fu_3779_p18.read();
        inp_load_2_1_2_phi_reg_18390 = inp_load_2_1_2_phi_fu_3801_p18.read();
        inp_load_2_1_4_phi_reg_18400 = inp_load_2_1_4_phi_fu_3854_p18.read();
        inp_load_2_2_0_phi_reg_18405 = inp_load_2_2_0_phi_fu_3876_p18.read();
        inp_load_2_2_4_phi_reg_18410 = inp_load_2_2_4_phi_fu_3898_p18.read();
        inp_load_2_3_2_phi_reg_18415 = inp_load_2_3_2_phi_fu_3920_p18.read();
        inp_load_2_4_0_phi_reg_18420 = inp_load_2_4_0_phi_fu_3942_p18.read();
        inp_load_2_4_3_phi_reg_18425 = inp_load_2_4_3_phi_fu_3964_p18.read();
        inp_load_3_0_2_phi_reg_18430 = inp_load_3_0_2_phi_fu_3986_p18.read();
        inp_load_3_1_0_phi_reg_18435 = inp_load_3_1_0_phi_fu_4008_p18.read();
        inp_load_3_1_2_phi_reg_18440 = inp_load_3_1_2_phi_fu_4030_p18.read();
        inp_load_3_1_4_phi_reg_18450 = inp_load_3_1_4_phi_fu_4083_p18.read();
        inp_load_3_2_0_phi_reg_18455 = inp_load_3_2_0_phi_fu_4105_p18.read();
        inp_load_3_2_4_phi_reg_18460 = inp_load_3_2_4_phi_fu_4127_p18.read();
        inp_load_3_3_2_phi_reg_18465 = inp_load_3_3_2_phi_fu_4149_p18.read();
        inp_load_3_4_0_phi_reg_18470 = inp_load_3_4_0_phi_fu_4171_p18.read();
        inp_load_3_4_3_phi_reg_18475 = inp_load_3_4_3_phi_fu_4193_p18.read();
        inp_load_4_0_2_phi_reg_18480 = inp_load_4_0_2_phi_fu_4215_p18.read();
        inp_load_4_1_0_phi_reg_18485 = inp_load_4_1_0_phi_fu_4237_p18.read();
        inp_load_4_1_2_phi_reg_18490 = inp_load_4_1_2_phi_fu_4259_p18.read();
        inp_load_4_1_4_phi_reg_18500 = inp_load_4_1_4_phi_fu_4312_p18.read();
        inp_load_4_2_0_phi_reg_18505 = inp_load_4_2_0_phi_fu_4334_p18.read();
        inp_load_4_2_4_phi_reg_18510 = inp_load_4_2_4_phi_fu_4356_p18.read();
        inp_load_4_3_2_phi_reg_18515 = inp_load_4_3_2_phi_fu_4378_p18.read();
        inp_load_4_4_0_phi_reg_18520 = inp_load_4_4_0_phi_fu_4400_p18.read();
        inp_load_4_4_3_phi_reg_18525 = inp_load_4_4_3_phi_fu_4422_p18.read();
        inp_load_5_0_2_phi_reg_18530 = inp_load_5_0_2_phi_fu_4444_p18.read();
        inp_load_5_1_0_phi_reg_18535 = inp_load_5_1_0_phi_fu_4466_p18.read();
        inp_load_5_1_2_phi_reg_18540 = inp_load_5_1_2_phi_fu_4488_p18.read();
        inp_load_5_1_4_phi_reg_18550 = inp_load_5_1_4_phi_fu_4541_p18.read();
        inp_load_5_2_0_phi_reg_18555 = inp_load_5_2_0_phi_fu_4563_p18.read();
        inp_load_5_2_4_phi_reg_18560 = inp_load_5_2_4_phi_fu_4585_p18.read();
        inp_load_5_3_2_phi_reg_18565 = inp_load_5_3_2_phi_fu_4607_p18.read();
        inp_load_5_4_0_phi_reg_18570 = inp_load_5_4_0_phi_fu_4629_p18.read();
        inp_load_5_4_3_phi_reg_18575 = inp_load_5_4_3_phi_fu_4651_p18.read();
        inp_load_6_0_2_phi_reg_18580 = inp_load_6_0_2_phi_fu_4673_p18.read();
        inp_load_6_1_0_phi_reg_18585 = inp_load_6_1_0_phi_fu_4695_p18.read();
        inp_load_6_1_2_phi_reg_18590 = inp_load_6_1_2_phi_fu_4717_p18.read();
        inp_load_6_1_4_phi_reg_18600 = inp_load_6_1_4_phi_fu_4770_p18.read();
        inp_load_6_2_0_phi_reg_18605 = inp_load_6_2_0_phi_fu_4792_p18.read();
        inp_load_6_2_4_phi_reg_18610 = inp_load_6_2_4_phi_fu_4814_p18.read();
        inp_load_6_3_2_phi_reg_18615 = inp_load_6_3_2_phi_fu_4836_p18.read();
        inp_load_6_4_0_phi_reg_18620 = inp_load_6_4_0_phi_fu_4858_p18.read();
        inp_load_6_4_3_phi_reg_18625 = inp_load_6_4_3_phi_fu_4880_p18.read();
        inp_load_7_0_2_phi_reg_18630 = inp_load_7_0_2_phi_fu_4902_p18.read();
        inp_load_7_1_0_phi_reg_18635 = inp_load_7_1_0_phi_fu_4924_p18.read();
        inp_load_7_1_2_phi_reg_18640 = inp_load_7_1_2_phi_fu_4946_p18.read();
        inp_load_7_1_4_phi_reg_18650 = inp_load_7_1_4_phi_fu_4999_p18.read();
        inp_load_7_2_0_phi_reg_18655 = inp_load_7_2_0_phi_fu_5021_p18.read();
        inp_load_7_2_4_phi_reg_18660 = inp_load_7_2_4_phi_fu_5043_p18.read();
        inp_load_7_3_2_phi_reg_18665 = inp_load_7_3_2_phi_fu_5065_p18.read();
        inp_load_7_4_0_phi_reg_18670 = inp_load_7_4_0_phi_fu_5087_p18.read();
        inp_load_7_4_3_phi_reg_18675 = inp_load_7_4_3_phi_fu_5109_p18.read();
        inp_load_8_0_2_phi_reg_18680 = inp_load_8_0_2_phi_fu_5131_p18.read();
        inp_load_8_1_0_phi_reg_18685 = inp_load_8_1_0_phi_fu_5153_p18.read();
        inp_load_8_1_2_phi_reg_18690 = inp_load_8_1_2_phi_fu_5175_p18.read();
        inp_load_8_1_4_phi_reg_18700 = inp_load_8_1_4_phi_fu_5228_p18.read();
        inp_load_8_2_0_phi_reg_18705 = inp_load_8_2_0_phi_fu_5250_p18.read();
        inp_load_8_2_4_phi_reg_18710 = inp_load_8_2_4_phi_fu_5272_p18.read();
        inp_load_8_3_2_phi_reg_18715 = inp_load_8_3_2_phi_fu_5294_p18.read();
        inp_load_8_4_0_phi_reg_18720 = inp_load_8_4_0_phi_fu_5316_p18.read();
        inp_load_8_4_3_phi_reg_18725 = inp_load_8_4_3_phi_fu_5338_p18.read();
        inp_load_9_0_2_phi_reg_18730 = inp_load_9_0_2_phi_fu_5360_p18.read();
        inp_load_9_1_0_phi_reg_18735 = inp_load_9_1_0_phi_fu_5382_p18.read();
        inp_load_9_1_2_phi_reg_18740 = inp_load_9_1_2_phi_fu_5404_p18.read();
        inp_load_9_1_4_phi_reg_18750 = inp_load_9_1_4_phi_fu_5457_p18.read();
        inp_load_9_2_0_phi_reg_18755 = inp_load_9_2_0_phi_fu_5479_p18.read();
        inp_load_9_2_4_phi_reg_18760 = inp_load_9_2_4_phi_fu_5501_p18.read();
        inp_load_9_3_2_phi_reg_18765 = inp_load_9_3_2_phi_fu_5523_p18.read();
        inp_load_9_4_0_phi_reg_18770 = inp_load_9_4_0_phi_fu_5545_p18.read();
        inp_load_9_4_3_phi_reg_18775 = inp_load_9_4_3_phi_fu_5567_p18.read();
        tmp_5_0_2_t_reg_18179 = tmp_5_0_2_t_fu_3378_p2.read();
        tmp_5_0_3_t_reg_18222 = tmp_5_0_3_t_fu_3406_p2.read();
        tmp_5_0_4_t_reg_18283 = tmp_5_0_4_t_fu_3500_p2.read();
        tmp_7_10_2_reg_18790 = tmp_7_10_2_fu_5637_p2.read();
        tmp_7_1_1_3_reg_18345 = tmp_7_1_1_3_fu_3620_p2.read();
        tmp_7_2_1_3_reg_18395 = tmp_7_2_1_3_fu_3849_p2.read();
        tmp_7_3_1_3_reg_18445 = tmp_7_3_1_3_fu_4078_p2.read();
        tmp_7_4_1_3_reg_18495 = tmp_7_4_1_3_fu_4307_p2.read();
        tmp_7_5_1_3_reg_18545 = tmp_7_5_1_3_fu_4536_p2.read();
        tmp_7_6_1_3_reg_18595 = tmp_7_6_1_3_fu_4765_p2.read();
        tmp_7_7_1_3_reg_18645 = tmp_7_7_1_3_fu_4994_p2.read();
        tmp_7_8_1_3_reg_18695 = tmp_7_8_1_3_fu_5223_p2.read();
        tmp_7_9_1_3_reg_18745 = tmp_7_9_1_3_fu_5452_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        tmp_9_0_0_1_reg_17787 = tmp_9_0_0_1_fu_3270_p1.read();
        tmp_9_0_0_2_reg_17802 = tmp_9_0_0_2_fu_3274_p1.read();
        tmp_9_0_0_3_reg_17817 = tmp_9_0_0_3_fu_3278_p1.read();
        tmp_9_0_0_4_reg_17832 = tmp_9_0_0_4_fu_3282_p1.read();
        tmp_9_0_1_1_reg_17862 = tmp_9_0_1_1_fu_3290_p1.read();
        tmp_9_0_1_2_reg_17877 = tmp_9_0_1_2_fu_3294_p1.read();
        tmp_9_0_1_3_reg_17892 = tmp_9_0_1_3_fu_3298_p1.read();
        tmp_9_0_1_4_reg_17907 = tmp_9_0_1_4_fu_3302_p1.read();
        tmp_9_0_1_reg_17847 = tmp_9_0_1_fu_3286_p1.read();
        tmp_9_0_2_1_reg_17937 = tmp_9_0_2_1_fu_3310_p1.read();
        tmp_9_0_2_2_reg_17952 = tmp_9_0_2_2_fu_3314_p1.read();
        tmp_9_0_2_3_reg_17967 = tmp_9_0_2_3_fu_3318_p1.read();
        tmp_9_0_2_4_reg_17982 = tmp_9_0_2_4_fu_3322_p1.read();
        tmp_9_0_2_reg_17922 = tmp_9_0_2_fu_3306_p1.read();
        tmp_9_0_3_1_reg_18012 = tmp_9_0_3_1_fu_3330_p1.read();
        tmp_9_0_3_2_reg_18027 = tmp_9_0_3_2_fu_3334_p1.read();
        tmp_9_0_3_3_reg_18042 = tmp_9_0_3_3_fu_3338_p1.read();
        tmp_9_0_3_4_reg_18057 = tmp_9_0_3_4_fu_3342_p1.read();
        tmp_9_0_3_reg_17997 = tmp_9_0_3_fu_3326_p1.read();
        tmp_9_0_4_1_reg_18087 = tmp_9_0_4_1_fu_3350_p1.read();
        tmp_9_0_4_2_reg_18102 = tmp_9_0_4_2_fu_3354_p1.read();
        tmp_9_0_4_3_reg_18117 = tmp_9_0_4_3_fu_3358_p1.read();
        tmp_9_0_4_4_reg_18132 = tmp_9_0_4_4_fu_3362_p1.read();
        tmp_9_0_4_reg_18072 = tmp_9_0_4_fu_3346_p1.read();
        tmp_9_reg_17772 = tmp_9_fu_3266_p1.read();
    }
}

void MatConv::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            } else {
                ap_NS_fsm = ap_ST_fsm_state1;
            }
            break;
        case 2 : 
            if ((!(esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_0)) && !(esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            } else if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
  esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
  esl_seteq<1,1,1>(exitcond3_fu_3366_p2.read(), ap_const_lv1_1) && 
  esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)))) {
                ap_NS_fsm = ap_ST_fsm_state6;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            }
            break;
        case 4 : 
            ap_NS_fsm = ap_ST_fsm_state1;
            break;
        default : 
            ap_NS_fsm = "XXX";
            break;
    }
}

}

